# -*- coding: utf-8 -*-
"""
Created on Mon Mar 10 19:40:32 2025

@author: Asad shaikh
"""

import streamlit as st
st.title("Titanic Survival Prediction App")