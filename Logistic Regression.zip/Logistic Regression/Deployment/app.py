# -*- coding: utf-8 -*-
"""
Created on Mon Mar 10 19:43:45 2025

@author: Asad shaikh
"""
import streamlit as st
import pickle
import numpy as np

# Load the trained model
with open("model.pkl", "rb") as f:
    model, scaler = pickle.load(f)

# Streamlit UI
st.title("Titanic Survival Prediction")
st.write("Enter passenger details to check survival probability.")

# User input fields
Pclass = st.selectbox("Passenger Class (1 = 1st, 2 = 2nd, 3 = 3rd)", [1, 2, 3])
Sex = st.radio("Sex", ["Male", "Female"])
Age = st.slider("Age", 0, 100, 25)
SibSp = st.number_input("Number of Siblings/Spouses Aboard", min_value=0, max_value=10, value=0)
Parch = st.number_input("Number of Parents/Children Aboard", min_value=0, max_value=10, value=0)
Fare = st.number_input("Fare Paid", min_value=0.0, max_value=600.0, value=30.0)
Embarked_Q = st.checkbox("Embarked at Queenstown?")
Embarked_S = st.checkbox("Embarked at Southampton?")

# Convert categorical inputs
Sex = 1 if Sex == "Male" else 0
input_data = np.array([[Pclass, Sex, Age, SibSp, Parch, Fare, int(Embarked_Q), int(Embarked_S)]])
input_data_scaled = scaler.transform(input_data)

# Make prediction
if st.button("Predict"):
    prediction = model.predict(input_data_scaled)
    prediction_proba = model.predict_proba(input_data_scaled)[0][1]
    
    result = "Survived!" if prediction[0] == 1 else "Did not survive"
    st.write(f"**Prediction:** {result}")
    st.write(f"**Survival Probability:** {prediction_proba:.2f}")
